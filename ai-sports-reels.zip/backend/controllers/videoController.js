const { listVideos, getVideoUrl } = require('../utils/s3');

exports.getAllVideos = async (req, res) => {
  try {
    const videos = await listVideos();
    res.json(videos);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getVideoById = async (req, res) => {
  try {
    const video = await getVideoUrl(req.params.id);
    res.json(video);
  } catch (err) {
    res.status(404).json({ error: 'Video not found' });
  }
};