const AWS = require('aws-sdk');

const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY_ID,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
  region: process.env.AWS_REGION
});

const BUCKET = process.env.S3_BUCKET_NAME;

exports.listVideos = async () => {
  const params = { Bucket: BUCKET, Prefix: 'videos/' };
  const data = await s3.listObjectsV2(params).promise();

  return data.Contents.map(file => ({
    id: file.Key,
    title: file.Key.replace('videos/', '').replace('.mp4', ''),
    url: `/api/videos/${encodeURIComponent(file.Key)}`
  }));
};

exports.getVideoUrl = async (key) => {
  const params = {
    Bucket: BUCKET,
    Key: key,
    Expires: 60 * 5 // 5 minutes
  };

  const signedUrl = await s3.getSignedUrlPromise('getObject', params);
  return { key, signedUrl };
};