'use client';
import { useEffect, useState } from 'react';

export default function ReelPlayer() {
  const [videos, setVideos] = useState([]);
  const [current, setCurrent] = useState(0);

  useEffect(() => {
    fetch('http://localhost:5000/api/videos')
      .then(res => res.json())
      .then(setVideos);
  }, []);

  const next = () => setCurrent((prev) => (prev + 1) % videos.length);

  return (
    <div className="w-full h-screen overflow-hidden relative">
      {videos.length > 0 && (
        <video
          src={videos[current].url}
          key={videos[current].id}
          autoPlay
          controls
          onEnded={next}
          className="w-full h-full object-cover"
        />
      )}
    </div>
  );
}