import ReelPlayer from '../components/ReelPlayer';

export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-black text-white">
      <h1 className="text-3xl font-bold mt-4">Sports Reels</h1>
      <ReelPlayer />
    </main>
  );
}